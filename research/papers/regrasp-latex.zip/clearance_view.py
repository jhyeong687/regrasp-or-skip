"""Record preparation from two sequences starting at the same measured pose."""
import argparse,json,sys
from pathlib import Path
import numpy as np
from PIL import Image

parser=argparse.ArgumentParser(description=__doc__)
for key in ("repo","scene","clearance_source","out"):
    parser.add_argument("--"+key.replace("_","-"),type=Path,required=True)
args=parser.parse_args()
sys.path.insert(0,str(args.repo.resolve()/"simulation/random_pick/recovery"))
from factorial import Snapshot, branch, occlusion, prepare_grasp, recovery
from latch.run import camera

class RecordingBench(recovery.RecoveryBench):
    final_phase=None
    def run(self,points,phase):
        super().run(points,phase)
        if phase==self.final_phase:
            Image.fromarray(self._render("paper_oblique",(960,540))).save(args.out/(self.label+".png"))
            self.end_xyz=self.data.xpos[self.object_id].copy()*1000

def fixture(world):
    occlusion.view_setup("marker_occlusion",True)(world)
    camera(world,"paper_oblique",(.385,-.125,.275),(.216,.021,.025),25)

args.out.mkdir(exist_ok=True,parents=True)
doc=json.loads(args.clearance_source.read_text())
d=next(r for r in doc["design"] if r["case"]["trial"]==13)
row=next(r for r in doc["records"] if r["case"]["trial"]==13)
case=recovery.Case(**d["case"]);profile=occlusion.GRADED_PROFILES[case.shape]
bench=RecordingBench(args.scene,"brick",visual_fixture=fixture,object_fixture=occlusion.object_mesh(profile))
bench.profile=profile
try:
    first,nominal,gap,_=prepare_grasp(bench,case,d["offset_ratio"],d["friction"],d["sign"])
    recovery.probe(bench,first,gap,lambda _: ())
    st=Snapshot.capture(bench);initial=bench.data.xpos[bench.object_id].copy()*1000
    cam=bench.data.cam("paper_oblique");meta=dict(initial_xyz=initial.tolist(),xmat=cam.xmat.reshape(3,3).tolist(),xpos=cam.xpos.tolist(),fovy_deg=25)
    for cleared,key in [(False,"actions"),(True,"clearance_actions")]:
        bench.label=key;bench.final_phase="return_to_support" if cleared else "open_jaws"
        score=branch(bench,st,"grip_reinforcement",first,nominal,gap,clear_before_descent=cleared)
        assert score==row[key]["grip_reinforcement"]
        meta[key]=dict(end_xyz=bench.end_xyz.tolist(),max_drift_mm=score["preparation_drift_mm_eval"])
    (args.out/"projection.json").write_text(json.dumps(meta,indent=2))
finally:
    bench.close()
