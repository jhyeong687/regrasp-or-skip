"""Render the manuscript figures and export the policy metrics used in the text."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np
from matplotlib import pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from PIL import Image
from figure_style import BLUE, GRAY, INK, TEAL, AMBER, load, panel, save
from pad_figure import pad_figure

cli=argparse.ArgumentParser()
cli.add_argument("--archive", type=Path,required=True)
cli.add_argument("--data",type=Path,required=True)
cli.add_argument("--layout",type=Path,required=True)
cli.add_argument("--out",type=Path,required=True)
args=cli.parse_args()
args.out.mkdir(parents=True,exist_ok=True)
archive, data, dest = args.archive,args.data,args.out
case=data/"figure-case-007"
field=data/"moved-object"
actions=("continue","position_correction","grip_reinforcement","recenter_and_reinforce")
nice=("Continue","Recenter","Reinforce","Recenter + reinforce")
suites=["crossed","transfer"]
rows=[load(archive/f"recovery-factorial-{s}"/"results.json")["records"] for s in suites]
new=load(field/"results.json")["records"]
assert len(new)==72
figw=7.05

def project(points, pos, right, up, back, width, height, fov):
    delta=np.atleast_2d(points)/1000-np.array(pos)
    focal=height/(2*np.tan(np.deg2rad(fov/2)))
    return np.c_[width/2-focal*(delta@right)/(delta@back),height/2+focal*(delta@up)/(delta@back)]

def detail_projection(xyz):
    pos=np.array([.365,-.205,.130])
    back=pos-[.215,-.006,.033]; back/=np.linalg.norm(back)
    right=np.cross([0,0,1],back);right/=np.linalg.norm(right)
    return project(xyz,pos,right,np.cross(back,right),back,960,540,29)[0]

def figure_one():
    fig=plt.figure(figsize=(figw,4.35))
    targets=load(case/"targets.json")
    xy=np.array([[p['x_mm'],p['y_mm']] for p in load(args.layout)['points']])
    for x,w,title,file in [(.0,.318,"A   Workspace","workspace"),(.335,.318,"B   End of closure","pinch")]:
        ax=fig.add_axes([x,.524,w,.39]);ax.imshow(Image.open(case/(file+".png")))
        ax.set_axis_off();fig.text(x+.002,.911,title,weight="bold",fontsize=8.7)
        if file=="pinch":
            sample=np.load(case/"pinch.npz")
            for xyz,lab,loc in [(sample["tcp_mm"],"Jaw center",(137,100)),(sample["object_mm"],"Part center",(718,435))]:
                pt=detail_projection(xyz)
                ax.plot(*pt,"+",color="white",ms=7,mew=1.2)
                ax.annotate(lab,pt,loc,ha="center",va="center",color="white",fontsize=7.2,
                            bbox=dict(fc=INK,ec="none",pad=1.6),arrowprops=dict(arrowstyle="-",color="white",lw=.75))
    f=np.load(case/"pinch.npz")["taxels"][:,:,2]; vmax=max(.1,np.ceil(f.max()*10)/10)
    fig.text(.676,.911,"C   Normal load at closure",weight="bold",fontsize=8.7)
    for i in (0,1):
        ax=fig.add_axes([.674+.165*i,.58,.14,.28]);force=f[i].clip(0)
        ax.scatter(*xy.T,s=7,color="#d4dbe0",lw=0);sel=force>.002
        dots=ax.scatter(*xy[sel].T,c=force[sel],s=20+36*force[sel]/vmax,
                        norm=Normalize(0,vmax),cmap="viridis",edgecolors="#33414a",lw=.3)
        ax.set_aspect("equal");ax.axis("off")
        ax.set_xlabel("");ax.set_title(["Left pad","Right pad"][i],fontsize=7.7,pad=0)
        ax.text(.5,-.11,f"{force.sum():.2f} N",ha="center",transform=ax.transAxes,fontsize=7.5)
    fig.text(.0,.448,"D   Same probe state, four recovery actions",fontsize=8.7,weight="bold")
    for i,(a,name) in enumerate(zip(actions,nice)):
        x=.002+i*.251
        ax=fig.add_axes([x,.121,.242,.26])
        ax.imshow(Image.open(case/a/"hold_retry.png"));ax.axis("off")
        panel(ax,"",name)
        row=targets["outcomes"][a];m=np.load(case/a/"hold_retry.npz")
        force=m["pads"].mean()
        ax.text(0,-.16,(f"Δx {targets['nominal'][0]-targets['first'][0]:+.0f} mm" if i in (1,3) else "Δx 0 mm")+("  ·  gap 14 mm" if i in (2,3) else "  ·  gap 28 mm"),transform=ax.transAxes,fontsize=7.2)
        ax.text(0,-.36,f"Mean pad load   {force:.2f} N",transform=ax.transAxes,fontsize=7.2)
        ax.text(0,-.56,"Placed in tray" if row["success"] else "Tray placement failed",transform=ax.transAxes,
                fontsize=7.2,weight="bold",color=TEAL if row["success"] else GRAY)
    save(fig,dest,"matched_grasps")

def coverage():
    fig,axes=plt.subplots(1,2,figsize=(figw,2.38),layout="constrained",sharey=True)
    for ax,rr,title in zip(axes,rows,["A   Main evaluation","B   Shape transfer"]):
        shapes={r["case"]["shape"] for r in rr}
        vals=sorted({r["offset_ratio"] for r in rr})
        # Friction rank within shape. Shapes have different reference friction.
        fr={s:sorted({r["friction"] for r in rr if r["case"]["shape"]==s},reverse=True) for s in shapes}
        n=len(next(iter(fr.values())))
        grid=np.zeros((3,n),int);count=np.zeros_like(grid)
        for r in rr:
            i=vals.index(r["offset_ratio"]);j=fr[r["case"]["shape"]].index(r["friction"])
            ac=r["clearance_actions"];count[i,j]+=1
            grid[i,j]+=all(not ac[a]["success"] for a in actions[:3]) and ac[actions[3]]["success"]
        ax.imshow(grid/count,vmin=0,vmax=1,cmap="Blues",aspect="auto")
        for (i,j),k in np.ndenumerate(grid):
            ax.text(j,i,f"{k}/{count[i,j]}",ha="center",va="center",color="white" if k/count[i,j]>.55 else INK,fontsize=8)
        ax.set_xticks(range(n),["0.80","+0.025","Ref.","−0.010"][:n]);ax.set_xlabel("Contact friction relative to shape reference")
        ax.set_yticks(range(3),[f"{v:.2f}" for v in vals]);panel(ax,"",title)
    axes[0].set_ylabel("Offset / half-width")
    save(fig,dest,"coverage")

def pick(r,d=2.5):
    c=r["contact"]["phases"]["closure"];h=r["contact"]["phases"]["hold"]
    vals=[abs(v) for v in c["median_contact_x_mm_left_right"] if v is not None]
    edge=c["bilateral_samples"]<4 or bool(vals) and np.mean(vals)>d
    return actions[int(edge)+2*int(h["bilateral_samples"]<8)]

def sensitivity():
    fig,axs=plt.subplots(1,2,figsize=(figw,2.6));fig.subplots_adjust(left=.085,right=.98,bottom=.24,top=.86,wspace=.32)
    for ix,(rr,title,col) in enumerate(zip(rows,["Main","Transfer"],[BLUE,AMBER])):
        x=np.arange(0,10.01,.10)
        y=[100*np.mean([r["clearance_actions"][pick(r,t)]["success"] for r in rr]) for t in x]
        axs[0].plot(x,y,color=col,label=title);axs[0].plot(2.5,y[25],"o",color=col,ms=4)
        layouts=list(dict.fromkeys(r["condition"] for r in rr))
        for j,shape in enumerate(dict.fromkeys(r["case"]["shape"] for r in rr)):
            selected=[r for r in rr if r["case"]["shape"]==shape]
            delta=[]
            for layout in dict.fromkeys(r["condition"] for r in selected):
                ss=[r for r in selected if r["condition"]==layout]
                delta.append(sum(int(r["clearance_actions"][pick(r)]["success"])-int(r["clearance_actions"][pick(r,np.inf)]["success"]) for r in ss))
            for k,v in enumerate(delta):
                axs[1].plot(v,j+ix*3+(k-(len(delta)-1)/2)*.14,"o",color=col,ms=4)
    axs[0].axvline(2.5,ls=":",lw=.8,color=GRAY);axs[0].set(xlabel="Closure-center threshold (mm)",ylabel="Successful placements (%)",ylim=(55,102));axs[0].legend(frameon=False,fontsize=7)
    axs[1].set(yticks=range(6),yticklabels=["Beveled","Rounded","Tapered","Hexagonal","Oval","Slanted"],xlabel="Extra placements per layout",xticks=range(5),xlim=(-.45,4.45));axs[1].invert_yaxis()
    panel(axs[0],"A","Threshold sensitivity");panel(axs[1],"B","Effect of adding contact location")
    save(fig,dest,"sensitivity")

def preparation():
    path=data/"figure-clearance-013"
    meta=load(path/"projection.json")
    fig,axs=plt.subplots(1,2,figsize=(figw,1.78))
    fig.subplots_adjust(left=.005,right=.995,bottom=.12,top=.80,wspace=.04)
    mat=np.asarray(meta["xmat"])
    for i,(ax,key,name) in enumerate(zip(axs,["actions","clearance_actions"],["Descend, then open","Open, then descend"])):
        ax.imshow(Image.open(path/(key+".png")))
        p1,p2=project([meta["initial_xyz"],meta[key]["end_xyz"]],meta["xpos"],*mat.T,960,540,25)
        center=p1
        ax.set(xlim=(center[0]-324,center[0]+324),ylim=(center[1]+119,center[1]-119))
        ax.plot(*p1,marker="o",ms=8,mfc="none",mec="white",mew=1)
        if np.linalg.norm(p2-p1)>5:
            ax.annotate("",xy=p2,xytext=p1,arrowprops=dict(arrowstyle="->",lw=1.5,color="white"))
        ax.plot(*p2,marker="+",ms=8,mew=1,color="white")
        ax.set_axis_off();panel(ax,"AB"[i],name)
        ax.text(.02,.05,f"Maximum drift   {meta[key]['max_drift_mm']:.1f} mm",color="white",
                fontsize=7.5,bbox=dict(fc=INK,ec="none",pad=1.8),transform=ax.transAxes)
    save(fig,dest,"preparation_frames")

def clearance():
    fig,axs=plt.subplots(1,2,figsize=(figw,2.48));fig.subplots_adjust(left=.09,right=.98,bottom=.24,top=.84,wspace=.38)
    for rr,s,color in zip(rows,["Main","Transfer"],[BLUE,AMBER]):
        eligible=[r for r in rr if r["clear_before_descent"]]
        for key,ls in [("actions","-"),("clearance_actions","--")]:
            values=sorted(r[key]["grip_reinforcement"]["preparation_drift_mm_eval"] for r in eligible)
            axs[0].step(values,np.arange(1,len(values)+1)/len(values),where="post",c=color,ls=ls,lw=1.65)
    axs[0].set(xlabel="Maximum planar displacement (mm)",ylabel="Fraction at or below",xlim=(-1,32),ylim=(0,1.05))
    axs[0].legend(handles=[Line2D([0],[0],color=BLUE,label="Main"),Line2D([0],[0],color=AMBER,label="Transfer")],frameon=False,fontsize=7,loc="lower right")
    doc=load(archive/"recovery-factorial-retention-ablation/results.json")
    # Source stores counts for each of the time-matched perturbations.
    sums=doc["summaries"]
    master=load(archive/"recovery-factorial-retention/results.json")["summaries"]
    merged={**master,**sums}
    keys=["hold","lateral_check","pitch_only","height_only","vertical_check"]
    vals=[merged[k].get("check_only",0) for k in keys]
    axs[1].barh(range(5),vals,color=[GRAY,GRAY,GRAY,TEAL,TEAL])
    axs[1].set(yticks=range(5),yticklabels=["Wait","Lateral","Pitch","Rise","Rise + pitch"],xlabel="Direct-carry failures recovered (of 15)",xlim=(0,15));axs[1].invert_yaxis()
    for i,v in enumerate(vals): axs[1].text(v+.3,i,str(v),va="center",fontsize=8)
    panel(axs[0],"A","Displacement during preparation");panel(axs[1],"B","Effect of an extra motion")
    save(fig,dest,"clearance")

def metrics(row,policy):
    if policy=="stale":return row["stale_combined"]
    a=actions[3] if policy=="both" else row["choices"][policy]
    return row["actions"][a]

def stale_evidence():
    fig=plt.figure(figsize=(figw,2.51))
    for i,r in enumerate([new[0],new[4]]):
        p=np.load(field/r["sensor_file"]);ax=fig.add_axes([.01+.31*i,.15,.295,.67])
        ax.imshow(p["refresh_rgb"]);mask=p["refresh_mask"]
        ax.contour(mask,levels=[.5],colors=["#58e6e2"],linewidths=.65)
        ys,xs=np.where(mask);xc=(xs.min()+xs.max())/2;yc=(ys.min()+ys.max())/2
        ax.set(xlim=(xc-97,xc+97),ylim=(yc+79,yc-79));ax.axis("off")
        panel(ax,"AB"[i],f"Trial {r['trial']} · shift {r['shift_mm']} mm")
        e=np.linalg.norm(np.array(r["hold_true_xy_eval"])-r["fresh"][:2])
        ax.text(0,-.16,f"Updated center error   {e:.1f} mm",transform=ax.transAxes,fontsize=7.5)
    ax=fig.add_axes([.701,.22,.278,.58]);xs=[0,12,24]
    for prefix,col,offset in [("first",GRAY,-.75),("fresh",BLUE,.75)]:
        median=[];quart=[]
        for s in xs:
            errors=[np.linalg.norm(np.array(r[prefix][:2])-r["hold_true_xy_eval"]) for r in new if r["shift_mm"]==s]
            q=np.percentile(errors,[25,50,75]);median.append(q[1]);quart.append([q[1]-q[0],q[2]-q[1]])
        ax.errorbar(np.array(xs)+offset,median,yerr=np.array(quart).T,fmt="o-",capsize=2,color=col,ms=3,lw=1,label="Wrist (initial)" if prefix=="first" else "Updated")
    panel(ax,"C","Center error");ax.set(xticks=xs,xlabel="Imposed shift (mm)",ylabel="XY error (mm)");ax.legend(frameon=False,fontsize=6.5)
    save(fig,dest,"refresh")

def shifted():
    fig,axs=plt.subplots(1,3,figsize=(figw,2.65));fig.subplots_adjust(left=.07,right=.98,bottom=.30,top=.83,wspace=.34)
    names=[("stale","Combined, stale",'#797d80','x'),("both","Combined, updated",TEAL,'o'),("spatial","Tactile selector",BLUE,'s'),("vision_gap","Vision + gap",AMBER,'^')]
    for pol,label,col,marker in names:
        buckets=[[metrics(r,pol) for r in new if r["shift_mm"]==s] for s in [0,12,24]]
        for ax,fieldname in zip(axs,["success","sim_s","peak_pad_normal_n"]):
            means=[np.mean([v[fieldname] for v in bucket]) for bucket in buckets]
            ax.plot([0,12,24],np.array(means)*(100 if fieldname=="success" else 1),lw=1,ms=4,marker=marker,c=col,label=label)
    for i,(ax,lbl) in enumerate(zip(axs,["Placement (%)","Post-probe motion (s)","Peak pad load (N)"])):
        panel(ax,"ABC"[i],lbl);ax.set_xticks([0,12,24]);ax.set_xlabel("Imposed shift (mm)")
    axs[0].set_ylim(0,106);axs[2].set_ylim(bottom=0)
    fig.legend(*axs[0].get_legend_handles_labels(),loc="lower center",ncol=4,fontsize=6.8,frameon=False)
    save(fig,dest,"shift_results")

if __name__=="__main__":
    figure_one();pad_figure(archive,args.layout,dest);coverage();sensitivity();preparation();clearance();stale_evidence();shifted()
