Run latexmk -pdf manuscript.tex from this directory. Figures are included as PDF files.
