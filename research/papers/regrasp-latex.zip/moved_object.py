"""Geometry-only reacquisition after a physical translation in a MuJoCo scene."""
import argparse
import json
from pathlib import Path
import sys

import mujoco as mj
import numpy as np
from PIL import Image

cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument("--repo", type=Path, required=True)
cli.add_argument("--scene", type=Path, required=True)
cli.add_argument("--out", type=Path, required=True)
cli.add_argument("--figures-only", action="store_true")
cli.add_argument("--clearance-source", type=Path)
args = cli.parse_args()
sys.path.insert(0, str(args.repo.resolve() / "simulation/random_pick/recovery"))
from factorial import ACTIONS, Snapshot, branch, occlusion, prepare_grasp, recovery
from factorial_analysis import phase_and_location
from latch.run import camera

CAM = "refresh_rgbd"
SEED = 26112772
PROFILES = occlusion.GRADED_PROFILES
SIZE = (640, 360)


class Bench(occlusion.OcclusionBench):
    def __init__(self, scene, shape):
        self.profile = PROFILES[shape]
        def fixture(world):
            occlusion.view_setup("marker_occlusion", True)(world)
            camera(world, CAM, (.38, -.25, .38), (.215, .0, .022), 34)
            camera(world, "detail", (.365, -.205, .130), (.215, -.006, .033), 29)
        recovery.RecoveryBench.__init__(self, scene, "brick", visual_fixture=fixture,
                                         object_fixture=occlusion.object_mesh(self.profile))
        self.archive_raw = False
        self.record_dir = None

    def run(self, points, phase):
        super().run(points, phase)
        if self.record_dir and phase in {"pinch", "probe_hold", "settle_grip", "hold_retry", "release"}:
            name = self.record_dir / phase
            Image.fromarray(self._render("detail", (960, 540))).save(name.with_suffix(".png"))
            sample = self.sample(phase)
            np.savez_compressed(name.with_suffix(".npz"), taxels=self.read_tactile()*recovery.COMPRESSION_POSITIVE,
                                pads=np.array([p["normal_n"] for p in sample["pads"]]),
                                tcp_mm=sample["tcp_mm"], gap_mm=sample["jaw_gap_mm"],
                                object_mm=sample["object_xyz_mm_eval"], sim_s=self.data.time)
            if phase in {"hold_retry", "release"}:
                Image.fromarray(self._render("pick_live", (960, 540))).save(self.record_dir / (phase+"-wide.png"))


def reacquire(bench):
    depth = bench._render(CAM, SIZE, "depth")
    rgb = bench._render(CAM, SIZE)
    r, g, b = rgb.astype(np.int16).transpose(2, 0, 1)
    mask = (r > g+23) & (g > b+20) & (r > 102) & (depth >= .195) & (depth < .8)
    row, col = np.nonzero(mask)
    z = depth[row, col]
    cam_id = bench.model.camera(CAM).id
    height, width = depth.shape
    f = height / (2*np.tan(np.deg2rad(bench.model.cam_fovy[cam_id]/2)))
    local = np.c_[(col+.5-width/2)*z/f, -(row+.5-height/2)*z/f, -z]
    world = (local @ bench.data.cam_xmat[cam_id].reshape(3, 3).T + bench.data.cam_xpos[cam_id])*1000
    valid = np.all((world > [145,-64,2]) & (world < [276,80,72]), axis=1)
    world = world[valid]
    kept = np.zeros_like(mask)
    kept[row[valid], col[valid]] = True
    top = world[world[:,2] >= np.percentile(world[:,2],92)-2.2] if len(world) else world
    center = np.mean(np.percentile(top[:,:2],[2,98],axis=0),axis=0).round(3).tolist() if len(top)>=24 else None
    return center, rgb, depth, kept, len(top)


def design():
    rng = np.random.default_rng(SEED)
    rows = []
    for shape in PROFILES:
        for layout in range(1,5):
            x,y,yaw = rng.uniform([205,-16,-9],[221,16,9])
            direction = 1 if layout in (1,4) else -1
            for shift in (0,12,24):
                for friction in (.8, .125 if shape != "tapered_block" else .115):
                    rows.append(dict(trial=len(rows)+1,shape=shape,layout=layout,x_mm=round(x,2),
                                     y_mm=round(y,2),yaw_deg=round(yaw,2),shift_mm=shift,
                                     dx_mm=shift*direction,friction=friction))
    return rows


def measure(bench, d, out):
    case = recovery.Case(**{k:d[k] for k in ("trial","shape","x_mm","y_mm","yaw_deg")})
    first, _, gap, sensed = prepare_grasp(bench, case, 0., d["friction"], 1)
    bench.data.qpos[bench.object_qpos] += d["dx_mm"]/1000
    bench.data.qvel[bench.object_dof:bench.object_dof+6] = 0.
    mj.mj_forward(bench.model, bench.data)
    bench.settle(.12)
    bench.trace = []
    bench.archive_raw = True
    recovery.probe(bench, first, gap, lambda _: ())
    center, rgb, depth, mask, n_top = reacquire(bench)
    xy_eval = (1000*bench.data.xpos[bench.object_id,:2]).round(3).tolist()
    fresh = first.copy()
    if center is not None:
        fresh[:2] = center
    arm, _ = recovery.summarize(bench.trace)
    contact = recovery.contact_history(bench.trace, gap)
    empty = abs(arm["hold"]["jaw_gap_mm"]-gap) <= recovery.EMPTY_CLOSURE_TOLERANCE_MM
    evidence_file = out / f"trial-{case.trial:03}.npz"
    np.savez_compressed(evidence_file, refresh_rgb=rgb,refresh_depth_m=depth,refresh_mask=mask,
                        wrist_mask=sensed[3],wrist_depth_m=sensed[1],wrist_K=sensed[4],
                        wrist_world_from_optical=sensed[5],refresh_cam_xmat=bench.data.cam(CAM).xmat,
                        refresh_cam_xpos=bench.data.cam(CAM).xpos,refresh_fovy=bench.model.camera(CAM).fovy,
                        forces_N=np.stack([t["_taxels"] for t in bench.trace]),
                        phase=[t["phase"] for t in bench.trace],sim_s=[t["sim_s"] for t in bench.trace])
    bench.archive_raw = False
    saved = Snapshot.capture(bench)
    actions = {a:branch(bench,saved,a,first,fresh,gap,clear_before_descent=empty) for a in ACTIONS}
    stale = branch(bench,saved,ACTIONS[3],first,first,gap,clear_before_descent=empty)
    assert branch(bench,saved,ACTIONS[0],first,fresh,gap,clear_before_descent=empty) == actions[ACTIONS[0]]
    shifted = np.linalg.norm(np.array(fresh[:2])-first[:2]) > 5.
    visual = ACTIONS[int(shifted)+2*int(empty)]  # continue, recenter, reinforce, both
    return dict(**d,first=first,fresh=fresh,refresh_available=center is not None,top_pixels=n_top,
                hold_true_xy_eval=xy_eval,gap_at_hold=arm["hold"]["jaw_gap_mm"],gate=empty,contact=contact,
                choices=dict(vision_gap=visual,timing=phase_and_location(contact,use_location=False),
                             spatial=phase_and_location(contact)),actions=actions,stale_combined=stale,
                sensor_file=evidence_file.name,sensor_sha256=recovery.digest(evidence_file),repeat_verified=True)


def figures(out):
    doc=json.loads(args.clearance_source.read_text())
    case_row=next(r for r in doc["records"] if r["case"]["trial"]==7)
    d=next(r for r in doc["design"] if r["case"]["trial"]==7)
    case=recovery.Case(**d["case"])
    bench=Bench(args.scene,case.shape)
    try:
        first,nominal,gap,_=prepare_grasp(bench,case,d["offset_ratio"],d["friction"],d["sign"])
        out.mkdir(parents=True,exist_ok=True)
        bench.record_dir=out
        Image.fromarray(bench._render("pick_live",(960,540))).save(out/"scene.png")
        recovery.probe(bench,first,gap,lambda _: ())
        saved=Snapshot.capture(bench)
        for a in ACTIONS:
            dest=out/a
            dest.mkdir(exist_ok=True)
            bench.record_dir=dest
            scored=branch(bench,saved,a,first,nominal,gap,clear_before_descent=case_row["clear_before_descent"])
            assert scored==case_row["clearance_actions"][a],(a,scored,case_row["clearance_actions"][a])
        recovery.write_json(out/"targets.json",dict(first=first,nominal=nominal,gap=gap,
                                                    outcomes=case_row["clearance_actions"]))
    finally:
        bench.close()


def main():
    if args.figures_only:
        return figures(args.out)
    out=args.out
    out.mkdir(parents=True,exist_ok=True)
    draws=design()
    spec=dict(seed=SEED,scene_sha256=recovery.digest(args.scene),runner_sha256=recovery.digest(Path(__file__)),
              mujoco=mj.__version__,design=draws)
    result_path=out/"results.json"
    doc=json.loads(result_path.read_text()) if result_path.exists() else dict(**spec,records=[])
    assert all(doc[k]==v for k,v in spec.items())
    recovery.write_json(out/"design.json",spec)
    benches={}
    try:
        for d in draws[len(doc["records"]):]:
            if d["shape"] not in benches:
                benches[d["shape"]]=Bench(args.scene,d["shape"])
            row=measure(benches[d["shape"]],d,out)
            doc["records"].append(row)
            recovery.write_json(result_path,doc)
            print(d["trial"],d["shape"],d["shift_mm"],row["fresh"][:2],flush=True)
    finally:
        for bench in benches.values():
            bench.close()


if __name__=="__main__":
    main()
