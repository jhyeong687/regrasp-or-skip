"""Render aligned pad measurements using common force and spatial scales."""
import hashlib
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from figure_style import BLUE,AMBER,GRAY,INK,load,save

def pad_figure(archive,layout,dest):
    directory=archive/"recovery-factorial-clearance"
    records={r["case"]["trial"]:r for r in load(directory/"results.json")["records"]}
    xy=np.asarray([(p["x_mm"],p["y_mm"]) for p in load(layout)["points"]])
    examples=[]
    for i,title in [(1,"Nominal grasp"),(5,"Low friction"),(7,"Offset and low friction")]:
        r=records[i];fn=directory/"observations"/r["observation"]["sensor_archive"]
        assert hashlib.sha256(fn.read_bytes()).hexdigest()==r["observation"]["sensor_sha256"]
        with np.load(fn) as s:
            norm=s["forces_N"][...,2];phase=s["phase"];ts=s["sim_s"]
        frame=np.flatnonzero(phase=="pinch")[-1]
        examples.append((title,r,ts,phase,norm,frame))
    vmax=np.ceil(10*max(f[t].max() for _,_,_,_,f,t in examples))/10
    scale=Normalize(0,vmax);fig=plt.figure(figsize=(7.05,3.28))
    for c,(title,r,ts,phase,norm,t) in enumerate(examples):
        x=.060+c*.314
        fig.text(x+.128,.965,title,ha="center",va="top",fontsize=9,weight="bold")
        for j in (0,1):
            ax=fig.add_axes([x+j*.132,.48,.127,.389]);f=norm[t,j].clip(0)
            ax.set_facecolor("#f3f6f7")
            ax.scatter(*xy.T,color="#aebcc4",s=6,lw=0)
            use=f>.002
            ax.scatter(*xy[use].T,c=f[use],cmap="viridis",norm=scale,s=15+30*f[use]/vmax,edgecolors="#33414a",lw=.32)
            if f.sum()>=.15:
                center=np.average(xy,axis=0,weights=f)
                ax.plot(*center,"+",ms=6,mew=1.8,color="white");ax.plot(*center,"+",ms=6,mew=.7,color=INK)
            ax.set(aspect="equal",xlim=(-14.7,14.7),ylim=(-3,32),xticks=[],yticks=[])
            for spine in ax.spines.values():spine.set_visible(False)
            ax.set_title(["Left","Right"][j],fontsize=7.4,pad=1.4)
        ax=fig.add_axes([x,.183,.263,.228])
        for keys,color in [(("close","pinch"),"#f4eee7"),(("probe_lift",),"#e1edf1"),(("probe_hold",),"#e5efe8")]:
            tt=ts[np.isin(phase,keys)]
            ax.axvspan(tt[0]-.02,tt[-1]+.02,color=color,lw=0)
        ax.plot(ts,norm[:,0].sum(axis=1),lw=1.25,c=BLUE)
        ax.plot(ts,norm[:,1].sum(axis=1),lw=1.1,c=AMBER,ls="--")
        ax.axvline(ts[t],c=INK,lw=.8,ls=":")
        ax.set(xlim=(2.18,4.18),ylim=(-.05,2.06),xticks=(2.4,3.2,4),yticks=(0,1,2))
        if c==0:ax.set_ylabel("Pad load (N)",labelpad=1)
        else:ax.set_yticklabels([])
        vals=r["contact"]["phases"];d=np.mean(np.abs(vals["closure"]["median_contact_x_mm_left_right"]))
        fig.text(x+.13,.089,f"Closure offset {d:.2f} mm  ·  Hold {vals['hold']['bilateral_samples']}/10",
                 ha="center",color=GRAY,fontsize=7.25)
    fig.text(.053,.016,"Pad load",fontsize=7.4,color=GRAY);fig.text(.12,.016,"━ Left",color=BLUE,fontsize=7.3)
    fig.text(.187,.016,"– – Right",color=AMBER,fontsize=7.3)
    fig.text(.5,.016,"Simulation time (s)",ha="center",fontsize=7.4)
    fig.text(.72,.016,"N / taxel",fontsize=7.2)
    bar=fig.add_axes([.80,.028,.12,.021])
    cb=fig.colorbar(ScalarMappable(norm=scale,cmap="viridis"),cax=bar,orientation="horizontal",ticks=[0,vmax])
    cb.ax.tick_params(length=0,pad=1,labelsize=6.4)
    save(fig,dest,"tactile_signals")
