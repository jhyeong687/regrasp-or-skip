"""Common vector figure styles and export settings."""
import json
import cairosvg
import matplotlib as mpl
import matplotlib.pyplot as plt

INK = "#18222b"
GRAY = "#576573"
LINE = "#dbe2e8"
LIGHT = "#eef2f5"
BLUE = "#216b8c"
TEAL = "#287b71"
AMBER = "#ab571c"

mpl.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8,
    "text.color": INK, "axes.labelcolor": INK,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": GRAY, "axes.linewidth": .55,
    "xtick.color": GRAY, "ytick.color": GRAY, "xtick.labelsize": 7,
    "ytick.labelsize": 7, "svg.fonttype": "path", "svg.hashsalt": "tactile-regrasp",
})


def load(path):
    return json.loads(path.read_text())


def save(figure, directory, name):
    svg = directory / (name + ".svg")
    figure.savefig(svg, dpi=210, metadata={"Date": None})
    cairosvg.svg2pdf(url=str(svg), write_to=str(directory / (name + ".pdf")))
    plt.close(figure)


def panel(ax, letter, label):
    ax.set_title(f"{letter}   {label}", loc="left", fontweight="bold", fontsize=8.6, pad=5)


