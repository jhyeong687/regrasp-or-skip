"""Full-workspace context at the same grasp closure as the case-7 detail."""
import argparse
import json
import sys
from pathlib import Path

from PIL import Image

p=argparse.ArgumentParser(description=__doc__)
for key in ("repo","scene","clearance_source","out"):
    p.add_argument("--"+key.replace("_","-"),type=Path,required=True)
args=p.parse_args()
sys.path.insert(0,str(args.repo.resolve()/"simulation/random_pick/recovery"))
from factorial import occlusion, prepare_grasp, recovery
from latch.run import camera

d=next(r for r in json.loads(args.clearance_source.read_text())["design"] if r["case"]["trial"]==7)
case=recovery.Case(**d["case"])
def fixture(world):
    occlusion.view_setup("marker_occlusion",True)(world)
    camera(world,"paper_workspace",(.52,-.59,.42),(.115,-.02,.115),38)
profile=occlusion.GRADED_PROFILES[case.shape]
bench=recovery.RecoveryBench(args.scene,"brick",visual_fixture=fixture,object_fixture=occlusion.object_mesh(profile))
bench.profile=profile
try:
    first,_,gap,_=prepare_grasp(bench,case,d["offset_ratio"],d["friction"],d["sign"])
    recovery.probe(bench,first,gap,lambda _: (),at_pinch=lambda:Image.fromarray(
        bench._render("paper_workspace",(1280,720))).save(args.out))
finally:
    bench.close()
