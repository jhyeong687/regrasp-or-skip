"""Validate matched outcomes and emit condition-level data for the paper."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
from collections import Counter
import numpy as np

cli=argparse.ArgumentParser()
cli.add_argument("--archive",type=Path,required=True)
cli.add_argument("--data",type=Path,required=True)
cli.add_argument("--out",type=Path,required=True)
args=cli.parse_args()
args.out.mkdir(exist_ok=True,parents=True)
action_names=["continue","position_correction","grip_reinforcement","recenter_and_reinforce"]
def load(p):
    return json.loads(p.read_text())

def choice(r,cut):
    c,h=(r["contact"]["phases"][k] for k in ("closure","hold"))
    vals=[abs(v) for v in c["median_contact_x_mm_left_right"] if v is not None]
    edge=c["bilateral_samples"]<4 or (vals and np.mean(vals)>cut)
    return action_names[int(bool(edge))+2*int(h["bilateral_samples"]<8)]

def write_csv(name,rows):
    with (args.out/name).open("w") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

totals={}
all_cases=[]
all_scores=[]
for suite,n in [("crossed",144),("transfer",81),("moved-object",72)]:
    moved=suite=="moved-object"
    directory=args.data/suite if moved else args.archive/("recovery-factorial-"+suite)
    doc=load(directory/"results.json")
    rows=doc["records"]; assert len(rows)==n and len({r.get("trial") if moved else r["case"]["trial"] for r in rows})==n
    samples=[]; full=[]
    for r in rows:
        trial=r["trial"] if moved else r["case"]["trial"]
        shape=r["shape"] if moved else r["case"]["shape"]
        lid=shape+"-"+str(r["layout"]) if moved else r["condition"]
        assert r["repeat_verified" if moved else "snapshot_repeat_verified"]
        if moved:
            fp=directory/r["sensor_file"]
            assert hashlib.sha256(fp.read_bytes()).hexdigest()==r["sensor_sha256"]
            with np.load(fp) as s:
                assert s["forces_N"].shape[1:]==(2,77,3) and s["refresh_depth_m"].shape==s["refresh_mask"].shape
        actions=r["actions" if moved else "clearance_actions"]
        assert set(actions)==set(action_names) and all(a["execution_error"] is None for a in actions.values())
        picks={a:actions[a] for a in action_names}
        picks.update(timing=actions[choice(r,np.inf)],spatial=actions[choice(r,2.5)])
        if moved:
            assert choice(r,np.inf)==r["choices"]["timing"] and choice(r,2.5)==r["choices"]["spatial"]
            picks.update(stale_combined=r["stale_combined"],vision_gap=actions[r["choices"]["vision_gap"]])
            assert picks["stale_combined"]==picks["grip_reinforcement"]
        samples.append((lid,picks));full.append(r)
        succ=[k for k,v in actions.items() if v["success"]]
        all_cases.append(dict(suite=suite,trial=trial,layout=lid,shape=shape,
            offset_ratio="" if moved else r["offset_ratio"],shift_mm=r["shift_mm"] if moved else "",
            friction=r["friction"],success_set="|".join(succ),spatial_action=choice(r,2.5),
            first_error_mm=np.linalg.norm(np.array(r["first"][:2])-r["hold_true_xy_eval"]) if moved else "",
            fresh_error_mm=np.linalg.norm(np.array(r["fresh"][:2])-r["hold_true_xy_eval"]) if moved else ""))
        for key,v in picks.items():
            all_scores.append(dict(suite=suite,trial=trial,layout=lid,policy=key,placed=int(v["success"]),
                                  post_probe_sim_s=v["sim_s"],peak_pad_load_N=v["peak_pad_normal_n"]))
    measures={}
    for policy in samples[0][1]:
        scores=[row[1][policy] for row in samples]
        measures[policy]=[sum(v["success"] for v in scores),round(np.mean([v["sim_s"] for v in scores]),3),
                          round(np.mean([v["peak_pad_normal_n"] for v in scores]),3)]
    pairs={}
    for a,b in [("spatial","timing"),("spatial",action_names[-1])]+([("spatial","vision_gap"),(action_names[-1],"stale_combined")] if moved else []):
        layouts=sorted(set(k for k,_ in samples))
        sizes={sum(k==key for k,_ in samples) for key in layouts}
        assert len(sizes)==1
        counts=Counter(sum(int(s[a]["success"])-int(s[b]["success"]) for k,s in samples if k==key) for key in layouts)
        # Enumerate the empirical bootstrap distribution with integer multiplicities.
        dist={0:1}
        for _ in layouts:
            next_dist=Counter()
            for total,ways in dist.items():
                for gain,units in counts.items():
                    next_dist[total+gain]+=ways*units
            dist=next_dist
        vals=sorted(dist)
        cdf=np.cumsum([dist[v] for v in vals])/sum(dist.values())
        ci=np.array([vals[int(np.searchsorted(cdf,q))]/n for q in (.025,.975)])
        pairs[a+" minus "+b]=dict(gains=sum(s[a]["success"] and not s[b]["success"] for _,s in samples),
                                   losses=sum(s[b]["success"] and not s[a]["success"] for _,s in samples),
                                   descriptive_layout_interval_pp=(100*ci).round(2).tolist())
    totals[suite]=dict(n=n,layout_count=len(set(k for k,_ in samples)),policies=measures,pairs=pairs,
        sweep={str(cut):sum(r["actions" if moved else "clearance_actions"][choice(r,cut)]["success"] for r in rows) for cut in (0,1,1.5,2,2.5,3,3.5,4,5,7,10)})
write_csv("conditions.csv",all_cases);write_csv("policy_scores.csv",all_scores)
(args.out/"paired_summary.json").write_text(json.dumps(totals,indent=2)+"\n")
